var Add = require('./Maths-V1');

// console.log(Add);

var result = Add(10,20)

console.log(result);


// var result = Add(10,20);
// console.log(result);