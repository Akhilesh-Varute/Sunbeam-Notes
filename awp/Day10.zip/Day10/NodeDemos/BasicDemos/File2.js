function SayBye()
{
    console.log("Bye")
}

module.exports = {SayBye};

//above statement is equal to :
// module.exports = {SayBye: SayBye};