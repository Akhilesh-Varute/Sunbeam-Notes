var Add = function(x, y){
    return x+ y;
}

var Sub = function(x, y){
    return x - y;
}


var Mult = function(x, y){
    return x * y;
}


module.exports = {
                  addition: Add,
                  subtraction: Sub,
                  mulitply : Mult 
                 };

                 //Below code means we are exporting 
                 //only Add and Mult functions 
                 //and not Sub function
//  module.exports = {
//                   addition: Add,
//                   mulitply : Mult 
//                  };