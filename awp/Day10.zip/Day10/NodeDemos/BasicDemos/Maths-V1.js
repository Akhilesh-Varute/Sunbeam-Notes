// function Add(x ,y )
// {
//     return x + y;
// }

var Add = function(x, y){
    return x+ y;
}

module.exports = Add;