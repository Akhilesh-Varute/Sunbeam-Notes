var v = require('./Maths-V2');
//above line is as good as:

// var v = {
//             addition: Add,
//             subtraction: Sub,
//             mulitply : Mult 
//         };

console.log(v);

var result1 = v.addition(10,20);
console.log(result1)

var result2 = v.subtraction(10,20);
console.log(result2)

var result3 = v.mulitply(10,20);
console.log(result3)