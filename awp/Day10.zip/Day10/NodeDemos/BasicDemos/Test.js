// console.log("Hi from node");

/////below line will throw error:
//// that would be : window is not defined

// window.setTimeout(()=>{console.log("hi")}, 1000);

//Testing variables, loops, functions

// var v = 100;
// console.log(v);
// console.log(typeof(v));

// v = "abcd";
// console.log(v);
// console.log(typeof(v));

// v = true;
// console.log(v);
// console.log(typeof(v));

// v = null;
// console.log(v);
// console.log(typeof(v));

// v = undefined;
// console.log(v);
// console.log(typeof(v));


//Loops

// for(var i = 0; i < 10; i ++)
// {
//     console.log(i);
// }


// var v = 10;
// if(v> 100)
// {
//     console.log("v is greater");
// }
// else
// {
//     console.log("miracle!")
// }


// var i = 0;
// while(true)
// {
//     i = i  +  1 ;
//     console.log(i);
//     if(i == 10)
//     {
//         break;
//     }
// }



// var i = 0;
// do
// {
//     i = i  +  1 ;
//     console.log(i);
//     if(i == 10)
//     {
//         break;
//     }
// }while(true)


