var Add = require('./Maths-V1');

var Print = function(){console.log("hi")}

//setTimeout(Print, 5000);

//setInterval(Print, 1000);

// console.log(global);

console.log(module);