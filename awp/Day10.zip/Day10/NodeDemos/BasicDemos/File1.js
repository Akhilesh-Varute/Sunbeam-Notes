function SayHi()
{
    console.log("Hi")
}

module.exports = {SayHi: SayHi};