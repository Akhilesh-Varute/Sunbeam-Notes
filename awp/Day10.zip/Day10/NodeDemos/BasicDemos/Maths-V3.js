var Add = function(x, y){
    return x+ y;
}

var Sub = function(x, y){
    return x - y;
}

var Mult = function(x, y){
    return x * y;
}

var interestRate = 12;

var programmerName = "MaheshP";

class Employee
{
    SayHi()
    {
        console.log("Hi Employees")
    }
}

var emp = new Employee();


module.exports = {
                  addition: Add,
                  subtraction: Sub,
                  mulitply : Mult,
                  interestRate: interestRate,
                  programmerName: programmerName,
                  emp : emp
                 };