var file1Contents = require('./File1');
var file2Contents = require('./File2');

console.log(module);
file1Contents.SayHi();
file2Contents.SayBye();
