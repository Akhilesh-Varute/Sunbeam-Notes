var v = require('./Maths-V3');

//above code / line is as good as below line:

// var v = {
//             addition: Add,
//             subtraction: Sub,
//             mulitply : Mult,
//             interestRate: interestRate,
//             programmerName: programmerName,
//             emp : emp
//             };

var result = v.addition(10,20);
console.log(result);

v.emp.SayHi();

console.log(v.interestRate);