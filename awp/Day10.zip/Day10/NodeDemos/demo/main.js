const maths = require('./src/maths');
const os = require('os');
const mysql = require('mysql')