const fs = require('fs');

console.log(" ---------- Hi ------------------- ")

fs.readdir("C:\\Users\\Admin\\OneDrive\\Desktop\\KDAC",
            (error, files)=>
            {
                if(error==null)
                {
                files.map((file)=>{console.log(file)});
                }
            });

console.log("---------- Bye ------------------- ")




// console.log(fs);