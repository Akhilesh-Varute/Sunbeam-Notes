const v = require('os');
//above statement is similar to :
//below statement
// var v = {arch : function (){},
//            freemem : function (){},
//            platform : function(){}}

// v = 100; //to avoid this situation; we declare v as const 

// console.log(v);

// console.log(v.arch());

// console.log(v.freemem())

// console.log(v.platform())