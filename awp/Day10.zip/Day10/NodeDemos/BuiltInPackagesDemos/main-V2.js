const fs = require('fs');

console.log("---------- Hi ------------------- ")


var files = fs.readdirSync("C:\\Users\\Admin\\OneDrive\\Desktop\\KDAC");

files.map((file)=>{console.log(file)});

console.log("---------- Bye ------------------- ")
// console.log(fs);