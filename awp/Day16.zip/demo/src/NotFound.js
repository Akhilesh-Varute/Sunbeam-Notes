function NotFound() {
    return ( <h1>Resource not found!!</h1> );
}

export default NotFound;