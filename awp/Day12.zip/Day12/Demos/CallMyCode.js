const GetMeSomething =  require('./MyCode');

const obj = GetMeSomething();

var result = obj.add(10,20);
console.log(result);