const express = require('express');
//console.log(express);

const app =  express();//..here express means createApplication Function


app.get("/emps", (request, response)=>{
    response.setHeader("Content-Type", 'text/plain');
    response.write("You asked for EMPS over GET");
    response.end();
});

app.post("/emps", (request, response)=>{
    response.setHeader("Content-Type", 'text/plain');
    response.write("You asked for EMPS over POST");
    response.end();
});

app.put("/emps", (request, response)=>{
    response.setHeader("Content-Type", 'text/plain');
    response.write("You asked for EMPS over PUT");
    response.end();
});

app.delete("/emps", (request, response)=>{
    response.setHeader("Content-Type", 'text/plain');
    response.write("You asked for EMPS over DELETE");
    response.end();
});

app.listen(9999, ()=>{console.log("server started at 9999")})
