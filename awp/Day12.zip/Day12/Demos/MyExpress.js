function CreateApplication()
{
    var contentToReturn = 
    {
        get : ()=>{console.log("GET Called.")},
        post : ()=>{},
        put : ()=>{},
        delete : ()=>{}
    }

    return contentToReturn;
}

CreateApplication.json  = ()=>{console.log("body creation code")};


module.exports = CreateApplication;

