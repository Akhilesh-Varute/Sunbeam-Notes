function GetMeSomething()
{
    var maths = 
    {
        add : function (x , y ){ return x+y; },
        sub : function (x , y ){ return x+y; },
        mult : function (x , y ){ return x+y; },
    }
    return maths;
}

module.exports = GetMeSomething;