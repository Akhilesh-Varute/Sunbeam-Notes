const express = require('express');

const app =  express();


app.use((request, response, next)=>{
    response.setHeader("Access-Control-Allow-Origin", "*");
    response.setHeader("Access-Control-Allow-Methods", "*");
    response.setHeader("Access-Control-Allow-Headers", "*");
    next();
})

app.use(express.json());//Express.JSON() acts as a middleware changing
                        //request.body. It sets request.body to actual
                        //contents sent in httpbody from client 
                        //compare express.json() with express.toString()

app.get("/emps", (request, response)=>{
    response.setHeader("Content-Type", 'application/json');
    var emp = {No : 1, Name: "Mahesh", Address: "Pune"};
    var empInString = JSON.stringify(emp);

    response.write(empInString);
    response.end();
});

app.post("/emps", (request, response)=>{

    console.log("Body received is ");
    console.log(request.body)
    
    response.setHeader("Content-Type", 'application/json');
    var emp = {No : 1, Name: "Mahesh", Address: "Pune"};
    var empInString = JSON.stringify(emp);

    response.write(empInString);
    response.end();
});


app.listen(9999, ()=>{console.log("server started at 9999")})
