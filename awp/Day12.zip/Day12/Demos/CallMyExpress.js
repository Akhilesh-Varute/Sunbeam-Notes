const express =  require('./MyExpress');
var app = express();


console.log(app)

app.get();

express.json()