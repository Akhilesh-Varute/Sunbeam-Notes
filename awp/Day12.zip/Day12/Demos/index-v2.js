const express = require('express');

const app =  express();

app.use((request, response, next)=>{
    response.write("ABCD");
    next();
   // response.end();
});

app.use((request, response, next)=>{
    response.write("XYZ");
    // next();
    //response.end();
});

app.get("/emps", (request, response)=>{
   // response.setHeader("Content-Type", 'text/plain');
    response.write("You asked for EMPS over GET");
    response.end();
});

app.post("/emps", (request, response)=>{
   // response.setHeader("Content-Type", 'text/plain');
    response.write("You asked for EMPS over POST");
    response.end();
});

app.listen(9999, ()=>{console.log("server started at 9999")})
