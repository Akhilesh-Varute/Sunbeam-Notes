const mysql = require('mysql');

const connection = mysql.createConnection({
                                             host : "localhost",
                                             database : "kdac",
                                             user : "root",
                                             password : "manager"
                                          });
connection.connect();

var statement = `select * from Emp`
connection.query(statement,(error, result)=>
                {
                    if(error==null)
                    {
                        console.log(result);

                        var resultInJSONString = JSON.stringify(result);
                        
                        console.log(resultInJSONString);

                    }
                    else
                    {
                        console.log(error);
                    }
                    connection.end();
                } )

 
