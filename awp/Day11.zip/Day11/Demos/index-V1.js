const http = require('http');

const helper = http.createServer((request, response)=>
                {
                    console.log(`You requested ${request.url}`)

                    response.setHeader("Content-Type", "text/plain")

                    response.write("some data from node");

                    response.end();
                })

helper.listen(9999,()=>{console.log("server started listening at port no 9999")})