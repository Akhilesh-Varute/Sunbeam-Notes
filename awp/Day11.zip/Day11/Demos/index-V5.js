
const http = require('http');
const mysql = require('mysql');

var connectionDetails = {
                            host : "localhost",
                            database : "kdac",
                            user : "root",
                            password : "manager"
                        };

const helper = http.createServer((request, response)=>
                {
                    console.log(`You requested URL:${request.url}`)
                    console.log(`You requested via ${request.method}`)

                    if(request.url == "/emps" && 
                       request.method == "GET")
                    {
                     var connection = mysql.createConnection(connectionDetails);

                     var statement = "select * from Emp";
                     
                     connection.query(statement, (error, result)=>{
                        if(error== null)
                        {
                            response.setHeader("Content-Type", "application/json");
                            var dataInStringFormat = 
                                    JSON.stringify(result);
                            connection.end();
                            response.write(dataInStringFormat);
                             response.end();
                            
                        }
                        else
                        {
                            response.setHeader("Content-Type", "application/json")
                             var errorInStringFormat = 
                                    JSON.stringify(error);
                            connection.end();
                            response.write(errorInStringFormat);
                             response.end();
                        }
                     })
                    }
                    else if(request.url == "/emps" && 
                       request.method == "POST")
                    {
                     var connection = mysql.createConnection(connectionDetails);

                     var statement = "insert into Emp values(6, 'Madhura', 'Pune')";
                     
                     connection.query(statement, (error, result)=>{
                        if(error== null)
                        {
                            response.setHeader("Content-Type", "application/json");
                            var dataInStringFormat = 
                                    JSON.stringify(result);
                            connection.end();
                            response.write(dataInStringFormat);
                             response.end();
                            
                        }
                        else
                        {
                            response.setHeader("Content-Type", "application/json")
                             var errorInStringFormat = 
                                    JSON.stringify(error);
                            connection.end();
                            response.write(errorInStringFormat);
                             response.end();
                        }
                     })
                    }
                    else
                    {
                    response.setHeader("Content-Type", "text/plain");
                    response.write("Sorry! We cant serve you! Try Again.");
                     response.end();
                    }

                })

helper.listen(9999,()=>{console.log("server started listening at port no 9999")})