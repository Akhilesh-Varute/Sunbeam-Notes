const http = require('http');

const helper = http.createServer((request, response)=>
                {
                    
                    console.log(`You requested ${request.url}`)

                    // console.log(`Your default language ${request.headers['accept-language']}`);
                    
                    console.log(`Your host name ${request.headers.host}`);

                    if(request.url == "/users")
                    {
                    response.setHeader("Content-Type", "application/json")

                    var person = {No: 1, Name: "Mahesh", Address: "Pune"};

                    var dataInStringFormat = 
                            JSON.stringify(person);
                    
                    response.write(dataInStringFormat);
                    }
                    else if(request.url == "/contact-us")
                    {
                    response.setHeader("Content-Type", "text/html");

                    var htmlInStringFormat = `<html>
                                        <head>
                                            <title>
                                             Contact Us!
                                            </title>
                                        </head>
                                        <body>
                                         <h1>
                                          contact us here!
                                         </h1>
                                        </body>
                                        </html>` 
                    response.write(htmlInStringFormat);

                    }
                    else if(request.url == "/")
                    {
                    response.setHeader("Content-Type", "text/html");

                     var htmlInStringFormat = `<html>
                                        <head>
                                            <title>
                                             Home!
                                            </title>
                                        </head>
                                        <body>
                                         <h1>
                                          Welcome Home
                                         </h1>
                                        </body>
                                        </html>` 
                    response.write(htmlInStringFormat);
                    }
                    else
                    {
                    response.setHeader("Content-Type", "text/plain");
                    response.write("Sorry! We cant serve you! Try Again.")
                    }

                    response.end();
                })

helper.listen(9999,()=>{console.log("server started listening at port no 9999")})