const express = require('express');
const app = express();
const appWithDetailsOfEmpsRoutes =  require('./routes/emps');
const appWithDetailsOfAdminRoutes =  require('./routes/admin');
const appWithDetailsOfProfileRoutes =  require('./routes/profile');
const appWithDetailsOfLoginRoutes =  require('./routes/auth');
const jwt = require('jsonwebtoken');

const cors = require('cors');
app.use(cors());
app.use(express.json())


//1.Comment below app.use once containing jwtToken.
//2.Run the demo
//3.Send username & password via postman using POST /login
//4. Get the token and see in it response
//5. No uncomment the code below app.use once containing jwtToken
//6. send a GET /emps call along with token details in BODY - in POSTMAN
//7. see that it is working and you are getting data - in POSTMAN
//8. see that you get a message "LOGIN FIRST" when you send call via
//   browser. reason you are not sending token via browser.
//   To send the token via browser; you will have to write code 
//   using XHR (in Javascript) or AXIOS (in React)

app.use((request, response, next)=>
{
  if(request.body.jwtToken!=undefined)
  {
    console.log("token received is ")
    console.log(request.body.jwtToken)

    var details = jwt.verify(request.body.jwtToken, "999999999")

    console.log(details);

    //logic to check if user is valid
    var isUserValid = (details.username=="mahesh" && details.token ==4675858);

    console.log("IS User Valid = " + isUserValid);

    if(isUserValid)
    {
      next()
    }
    else
    {
      response.write("User is not valid!");
      response.end();
    }
  }
  else
  {
      response.write("Login First!!");
      response.end();
  }

})

app.use("/login", appWithDetailsOfLoginRoutes)
app.use("/emps", appWithDetailsOfEmpsRoutes)
app.use("/admin", appWithDetailsOfAdminRoutes)
app.use("/profile", appWithDetailsOfProfileRoutes)


app.listen(9999, ()=>{console.log("server started")})