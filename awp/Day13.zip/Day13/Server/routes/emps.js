const express = require('express');
const app = express.Router();

const mysql = require('mysql');

const connectionDetails  = {
                                host: "localhost",
                                database: "kdac",
                                user: "root",
                                password: "manager"
                           }

app.get("/", (request, response)=>
{
  var statement = `select * from Emp`;
  var connection = mysql.createConnection(connectionDetails);
  connection.query(statement, (error, result)=>{
    if(error==null)
    {
        console.log("GET call received for /emps ");
        response.setHeader("Content-Type", "application/json");
        connection.end();
        response.write(JSON.stringify(result));
        response.end();  
    }
    else
    {
        console.log("GET call received for /emps ");
        response.setHeader("Content-Type", "application/json");
        connection.end();
        response.write(JSON.stringify(error));
        response.end();  
    }
  })
})

app.post("/", (request, response)=>
{
  
  var statement = `insert into Emp values(${request.body.No}, '${request.body.Name}', '${request.body.Address}')`;

  console.log(statement);

  var connection = mysql.createConnection(connectionDetails);
  connection.query(statement, (error, result)=>{
    if(error==null)
    {
        console.log("POST call received for /emps ");
        response.setHeader("Content-Type", "application/json");
        connection.end();
        response.write(JSON.stringify(result));
        response.end();  
    }
    else
    {
        console.log("POST call received for /emps ");
        response.setHeader("Content-Type", "application/json");
        connection.end();
        response.write(JSON.stringify(error));
        response.end();  
    }
  })
})

module.exports = app;