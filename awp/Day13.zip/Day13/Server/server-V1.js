const express = require('express');
const app = express();
const mysql = require('mysql');
const cors = require('cors');


const connectionDetails  = {
                                host: "localhost",
                                database: "kdac",
                                user: "root",
                                password: "manager"
                           }

app.use(cors());
// app.use((request, response, next)=>{
//     response.setHeader("Access-Control-Allow-Origin", "*")
//     response.setHeader("Access-Control-Allow-Methods", "*")
//     response.setHeader("Access-Control-Allow-Headers", "*")
//     next();
// })

app.use(express.json())

app.get("/emps", (request, response)=>
{
  var statement = `select * from Emp`;
  var connection = mysql.createConnection(connectionDetails);
  connection.query(statement, (error, result)=>{
    if(error==null)
    {
        console.log("GET call received for /emps ");
        response.setHeader("Content-Type", "application/json");
        connection.end();
        response.write(JSON.stringify(result));
        response.end();  
    }
    else
    {
        console.log("GET call received for /emps ");
        response.setHeader("Content-Type", "application/json");
        connection.end();
        response.write(JSON.stringify(error));
        response.end();  
    }
  })
})

app.post("/emps", (request, response)=>
{
  
  var statement = `insert into Emp values(${request.body.No}, '${request.body.Name}', '${request.body.Address}')`;

  console.log(statement);

  var connection = mysql.createConnection(connectionDetails);
  connection.query(statement, (error, result)=>{
    if(error==null)
    {
        console.log("POST call received for /emps ");
        response.setHeader("Content-Type", "application/json");
        connection.end();
        response.write(JSON.stringify(result));
        response.end();  
    }
    else
    {
        console.log("POST call received for /emps ");
        response.setHeader("Content-Type", "application/json");
        connection.end();
        response.write(JSON.stringify(error));
        response.end();  
    }
  })
})




// app.get("/emps", (request, response)=>
// {
//   var result = [{No: 1, Name: "Mahesh", Address: "Pune"},
//                 {No: 2, Name: "Nilesh", Address: "Pune"},
//                 {No: 3, Name: "Suresh", Address: "Pune"}
//                 ]
//   console.log("GET call received for /emps ");
//   response.setHeader("Content-Type", "application/json")
//   response.write(JSON.stringify(result));
//   response.end();  
// // response.send("Hello");
// })



// app.get("/emps", (request, response)=>{
//   console.log("GET call received for /emps ");
//   response.setHeader("Content-Type", "text/plain")
//   response.write("Hello");
//   response.end();  
// // response.send("Hello");
// })


app.listen(9999, ()=>{console.log("server started")})