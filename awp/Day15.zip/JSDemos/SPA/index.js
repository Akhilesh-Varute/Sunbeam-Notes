function navigate(page) {
        var refToRoot = document.getElementById("root");
        var content = ``;

        switch (page) {
          case "home":
            //When Home is class
            var obj = new Home();
            content = obj.render();

            //When home is function
            // content = home();
            break;
          case "about":
            content = about();
            break;
          case "contact":
            content = contact();
            break;
          default:
            content = `Can't get requested resource!`;
            break;
        }

        refToRoot.innerHTML = content;
      }

      navigate("home");