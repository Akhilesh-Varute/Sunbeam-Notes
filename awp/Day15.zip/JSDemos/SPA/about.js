function about()
{
    //imagine here huge logic for 
    //creating UI for About screen
    return `<h1>About Us!</h1>
      <br /><br /><br /><br /><br /><br /><br />`;
}