// function home()
// {
//     //imagine here huge logic for 
//     //creating UI for Home screen
//     return `<h1>Welcome Home</h1>
//       <br /><br /><br /><br /><br /><br /><br />`;
// }

class Home
{
    render()
    {
        //imagine here huge logic for 
        //creating UI for Home screen
        return `<h1>Welcome Home</h1>
        <br /><br /><br /><br /><br /><br /><br />`;
        }
}