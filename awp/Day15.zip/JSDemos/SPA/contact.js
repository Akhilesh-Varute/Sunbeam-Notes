function contact()
{
    //imagine here huge logic for 
    //creating UI for Contact screen
    return `<h1>Contact Us!</h1>
      <br /><br /><br /><br /><br /><br /><br />`;
}