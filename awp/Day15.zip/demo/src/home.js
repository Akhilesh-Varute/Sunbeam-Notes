import React, { Component } from "react";


class Home1 extends Component
{
    state ={emp:{username:"Mahesh", Address: "Pune"}}

    dosomething = ()=>
    {
        // var emp1 = {...this.state.emp}
        // emp1.username = "Nilesh";

          var emp1 = {...this.state.emp, username : "Nilesh"}
       

        this.setState({emp:emp1})
    }
    render()
    {
        //debugger;
        return <div>
                     <h1>Welcome {this.state.emp.username}</h1>
                     <h2>From {this.state.emp.Address}</h2>
                    <button onClick={this.dosomething}>
                        Click Me
                    </button>
               </div>
        // return (
        //         <table>
        //             <tbody>
        //                 <tr>
        //                 <td>1</td>
        //                 <td>mahesh</td>
        //                 <td>pune</td>
        //             </tr>
        //             </tbody>
        //         </table>  
        //       )

            // return (
            //         <>
            //         <h1>Welcome Home from class component</h1>
            //         <h2>hi</h2>
            //         <h3>abcd</h3>
            //        </>)

            //   return <React.Fragment>
            //             <h1>Welcome Home from class component</h1>
            //             <h2>hi</h2>
            //             <h3>abcd</h3>
            //         </React.Fragment>

        //   return <>
        //             <h1>Welcome Home from class component</h1>
        //             <h2>hi</h2>
        //             <h3>abcd</h3>
        //         </>
        //  return <div>
        //             <h1>Welcome Home from class component</h1>
        //             <h2>hi</h2>
        //             <h3>abcd</h3>
        //         </div>
    }
}

export default Home1;