
//Function Component in React
// function Home()
// {
//     return <h1>Welcome Home</h1>
// }

import React, { Component } from "react";


class Home1 extends Component
{
    //username = "Mahesh";

    state = {username:"Mahesh", Address: "Pune"}

    dosomething = ()=>{
        //console.log("Hi from react button")
        //debugger;
       
        this.setState({username:"abcd"})
    }
    render()
    {
        //debugger;
        return <div>
                    {/* <h1>Welcome {this.username}</h1> */}
                     <h1>Welcome {this.state.username}</h1>
                     <h2>From {this.state.Address}</h2>
                    <button onClick={this.dosomething}>
                        Click Me
                    </button>
               </div>
        // return (
        //         <table>
        //             <tbody>
        //                 <tr>
        //                 <td>1</td>
        //                 <td>mahesh</td>
        //                 <td>pune</td>
        //             </tr>
        //             </tbody>
        //         </table>  
        //       )

            // return (
            //         <>
            //         <h1>Welcome Home from class component</h1>
            //         <h2>hi</h2>
            //         <h3>abcd</h3>
            //        </>)

            //   return <React.Fragment>
            //             <h1>Welcome Home from class component</h1>
            //             <h2>hi</h2>
            //             <h3>abcd</h3>
            //         </React.Fragment>

        //   return <>
        //             <h1>Welcome Home from class component</h1>
        //             <h2>hi</h2>
        //             <h3>abcd</h3>
        //         </>
        //  return <div>
        //             <h1>Welcome Home from class component</h1>
        //             <h2>hi</h2>
        //             <h3>abcd</h3>
        //         </div>
    }
}

export default Home1;