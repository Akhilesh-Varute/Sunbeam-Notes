package com.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.CategoryDao;
import com.app.dao.ProductDao;
import com.app.dto.AddProductDTO;
import com.app.dto.ProductRespDTO;
import com.app.entities.Category;
import com.app.entities.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	// dep :
	@Autowired
	private ProductDao productDao;

	@Autowired
	private ModelMapper mapper;

	@Autowired
	private CategoryDao categoryDao;

	@Override
	public ProductRespDTO addNewProduct(AddProductDTO dto) {
		// get category by it's id
		Category category = categoryDao.findById(dto.getCategoryId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid category ID !!!"));
		//category : persistent
		//map product dto --> product entity
		Product product = mapper.map(dto, Product.class);
		//validate if : product name alrdy exists --if yes --
		//throw the exc --don't add the product
		
		//establish uni dir asso
		product.setProductCategory(category);
		//save 
		return mapper.map(productDao.save(product),
				ProductRespDTO.class);
		
	}

}
