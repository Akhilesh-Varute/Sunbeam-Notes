package com.app.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


//lombok annotations
@Getter
@Setter
//JPA annotations
@Entity
@Table(name = "products")
public class Product extends BaseEntity {
	@Column(length = 30,unique = true)
	private String productName;
	private String description;
	private double price;
	private int availableStock;
	private LocalDate expDate;
	//Product *----->1 Category (uni dir association)
	//product : many , child , owning side
	//Product HAS-A Category
	@ManyToOne
	@JoinColumn(name="category_id",nullable = false)
	private Category productCategory;
	
}
