package com.app.service;

import com.app.dto.AddProductDTO;
import com.app.dto.ProductRespDTO;

public interface ProductService {

	ProductRespDTO addNewProduct(AddProductDTO dto);

}
