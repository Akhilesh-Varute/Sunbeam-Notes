package com.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AddProductDTO;
import com.app.dto.ProductRespDTO;
import com.app.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	// dep
	@Autowired
	private ProductService productService;
	// Add REST API end point to add the product in the existing category
	//URL : http://host:port/products , method=POST
	//resp : product resp dto
	@PostMapping
	public ProductRespDTO addNewProduct(@RequestBody @Valid AddProductDTO dto)
	{
		System.out.println("in add new product "+dto);
		return productService.addNewProduct(dto);
	}

}
