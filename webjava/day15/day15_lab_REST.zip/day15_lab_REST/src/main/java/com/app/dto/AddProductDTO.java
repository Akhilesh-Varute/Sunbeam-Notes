package com.app.dto;

import java.time.LocalDate;

import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class AddProductDTO {
	// add validation rules here : since this DTO representation will be sent by
	// rest clnt
	@NotNull
	private Long categoryId;// category id : sent by client
	@NotBlank
	private String productName;
	private String description;
	@Max(500)
	private double price;
	private int availableStock;
	@Future
	private LocalDate expDate;
}
