package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.CategoryDTO;
import com.app.service.CategoryService;

@RestController
@RequestMapping("/categories")
public class CategoryController {
	@Autowired
	private CategoryService categoryService;
	//Add REST API end point for adding new category
	//URL : http://host:port/categories , method=POST
	//payload : category dto (w/o id)
	//resp : category dto(with generated cat id)
	@PostMapping
	public CategoryDTO addNewCategory(@RequestBody CategoryDTO dto)
	{
		System.out.println("in add new category");
		return categoryService.addNewCategory(dto);
	}

}
