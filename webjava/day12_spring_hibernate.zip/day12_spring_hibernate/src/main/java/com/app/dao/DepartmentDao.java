package com.app.dao;

import java.util.List;

import com.app.pojos.Department;

public interface DepartmentDao {
//add a method to list all depts
	List<Department> listAllDepartments();
}
