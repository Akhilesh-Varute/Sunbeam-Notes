package com.app.service;

import java.util.List;

import com.app.pojos.Department;

public interface DepartmentService {
//add a method to list all depts
	List<Department> getAllDepartments();
}
