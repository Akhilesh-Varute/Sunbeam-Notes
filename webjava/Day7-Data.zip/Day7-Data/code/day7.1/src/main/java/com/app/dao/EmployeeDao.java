package com.app.dao;

import com.app.pojos.Employee;

public interface EmployeeDao {
//add a method to insert emp details
	String addEmployeeDetails(Employee newEmp);
}
