package com.app.pojos;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "projects")
public class Project extends BaseEntity {
	@Column(length = 100,unique = true)
	private String title;
	@Column(name = "start_date")
	private LocalDate startDate;
	@Column(name = "end_date")
	private LocalDate endDate;
	private double budget;
	//many , parent , owning
	//As per Gavin King's suggestion : use Set instead of a List , 
	//to improve performance while removing the elems from the Set
	@ManyToMany(cascade = CascadeType.PERSIST)
	//optional anno to specify name of the child table n it's cols.
	@JoinTable(name="my_project_emps",
	joinColumns = @JoinColumn(name="proj_id"),
	inverseJoinColumns = @JoinColumn(name="emp_id"))
	private Set<Employee> employees=new HashSet<>();

	public Project() {
		// TODO Auto-generated constructor stub
	}

	public Project(String title, LocalDate startDate, LocalDate endDate, double budget) {
		super();
		this.title = title;
		this.startDate = startDate;
		this.endDate = endDate;
		this.budget = budget;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public double getBudget() {
		return budget;
	}

	public void setBudget(double budget) {
		this.budget = budget;
	}
	

	public Set<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}
	
	

	@Override
	public String toString() {
		return "Project [title=" + title + ", startDate=" + startDate + ", endDate=" + endDate + ", budget=" + budget
				+ "]";
	}

	//override hashCode n equals as per the contract
	@Override
	public int hashCode() {
		return Objects.hash(title);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		return Objects.equals(title, other.title);
	}

}
