package dependent;

import dependency.Transport;

public class ATMImpl implements ATM {
	private Transport myTransport;// depcy : loose coupling
	// Tight coupling => when you make a change in depcy ,
	// you have to make changes in the depnt. : un desirable

	// cash component
	private double cash;// mandatory
	// Can't be invoked by SC !

	private ATMImpl(double cash1234, Transport t123) {
		this.cash = cash1234;
		this.myTransport = t123;
		System.out.println("in cnstr of " + getClass().getName() + " " + cash + " " + myTransport);
		// 500000 null=> mandatory
	}

	@Override
	public void deposit(double amt) {
		System.out.println("depositing " + amt);
		byte[] data = ("depositing " + amt).getBytes();
		myTransport.informBank(data);// depnt obj is using
		// the depcy to inform backend bank

	}

	@Override
	public void withdraw(double amt) {
		System.out.println("withdrawing " + amt);
		byte[] data = ("withdrawing " + amt).getBytes();
		myTransport.informBank(data);// depnt is using
		// the depcy for informing the bank
	}

	// init method is invoked for singleton n prototype beans
	// after D.I
	// For singleton n eager : @ SC startup , 1 time
	// For singleton n lazy : @ 1st demand(ctx.getBean) , 1 time
	// For prototype (ALWAYS lazy !) : per every demand
	public void anyInit() {
		System.out.println("in init " + cash + " " + myTransport);// not null
	}

	// destroy method -- @ end of life cycle --> Before G.C --> for
	// singleton beans only !
	public void anyDestroy() {
		System.out.println("in destroy " + myTransport);// not null
	}

	// no setters => setter based D.I --- impossible here.
	// Factory method based D.I
	public static ATMImpl anyFactoryMethod(double cash1, Transport t1) {
		System.out.println("in factory method");
//invoke private ctor
		return new ATMImpl(cash1, t1);
	}

}
