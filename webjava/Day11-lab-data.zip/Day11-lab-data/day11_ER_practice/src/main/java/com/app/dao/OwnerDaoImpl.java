package com.app.dao;

import static com.app.utils.HibernateUtils.getFactory;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.pojos.Owner;

public class OwnerDaoImpl implements OwnerDao {

	@Override
	public String addNewOwner(Owner newOwner) {
		String mesg="Adding new owner failed ....";
		// 1. get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(newOwner);
			tx.commit();
			mesg="added new owner with id="+newOwner.getId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return mesg;
	}

}
