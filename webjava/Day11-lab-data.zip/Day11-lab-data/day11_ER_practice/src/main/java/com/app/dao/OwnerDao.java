package com.app.dao;

import com.app.pojos.Owner;

public interface OwnerDao {
//add a method to insert new owner details
	String addNewOwner(Owner newOwner);
}
