package com.app.tester;

import org.hibernate.*;

import com.app.dao.TeamDaoImpl;
import com.app.pojos.Team;

import static com.app.utils.HibernateUtils.getFactory;

import java.util.Scanner;

public class AddNewTeam {

	public static void main(String[] args) {
		// get SF from utils
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			// create team dao
			TeamDaoImpl teamDao = new TeamDaoImpl();
			System.out.println("Enter owner's email ");
			String email = sc.next();
			System.out.println("Enter Team details :  name,  abbreviation, maxAge,  battingAvg,  wicketsTaken");
			// create team instance
			Team newTeam = new Team(sc.next(), sc.next(), sc.nextInt(), sc.nextDouble(), sc.nextInt());
			// call dao's method for persistence
			System.out.println(teamDao.assignTeamToOwner(email,newTeam));
		} // sf.close() --> Hibernate will auto clean up DBCP
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
