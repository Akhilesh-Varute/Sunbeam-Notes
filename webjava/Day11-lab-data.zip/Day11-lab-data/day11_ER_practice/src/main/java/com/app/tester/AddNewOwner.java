package com.app.tester;

import org.hibernate.*;

import com.app.dao.OwnerDao;
import com.app.dao.OwnerDaoImpl;
import com.app.dao.TeamDaoImpl;
import com.app.pojos.Owner;
import com.app.pojos.Team;

import static com.app.utils.HibernateUtils.getFactory;

import java.util.Scanner;

public class AddNewOwner {

	public static void main(String[] args) {
		// get SF from utils
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			// create owner dao
			OwnerDao dao = new OwnerDaoImpl();
			System.out.println("Enter owner details : first name , last name ,email");
			System.out.println(dao.addNewOwner
					(new Owner(sc.next(), sc.next(), sc.next())));
		} // sf.close() --> Hibernate will auto clean up DBCP
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
