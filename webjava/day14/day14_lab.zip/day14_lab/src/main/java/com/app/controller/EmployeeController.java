package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.entities.Employee;
import com.app.service.EmployeeService;

@RestController // =@Controller : class level +
//@ResponseBody : added implicitly on ret types of req handling methods
@RequestMapping("/employees")
@CrossOrigin(origins = "http://localhost:3000")
public class EmployeeController {
//dependency : service layer i/f
	@Autowired
	private EmployeeService empService;

	public EmployeeController() {
		System.out.println("in ctor of " + getClass());
	}

	// URL : http://host:port/employees , method=GET
	@GetMapping
	public /* @ResponseBody */ List<Employee> listEmps() {
		System.out.println("in list emps");
		return empService.getAllEmps();
	}

	// URL : http://host:port/employees , method=POST
	// payload : JSON representation of emp(transient)
	@PostMapping
	public Employee addEmpDetails(@RequestBody Employee emp)
	// @RequestBody => method arg level annotation , in req handling methods
	// => un marshalling(=de ser) JSON ---> Java , performed by Jackson
	{
		System.out.println("in add emp " + emp);// id : null
		return empService.addEmpDetails(emp);
	}// handler(RestController) --> @ResponseBody(Java --> JSON) Employee
		// rets representation(JSON) of detached entity to the caller(REST
		// consumer of the REST API
	/*
	 * URL : http://host:port/employees/empId method: GET
	 */

	@GetMapping("/{empId}") // template URI variable : path variable
	// @PathVariable : method arg level anno for data binding between
	// incoming path var --> methd arg
	public Employee getEmpDetails(@PathVariable Long empId) {
		System.out.println("in get emp details " + empId);
		// return emp details to the REST clnt
		return empService.getEmpDetails(empId);
	}

	// URL : http://host:port/employees , method=PUT
	// payload : request body : representation of updated detached emp
	@PutMapping
	public Employee updateEmpDetails(@RequestBody Employee emp) {
		System.out.println("in update emp " + emp);// id must be not null !
		return empService.updateEmpDetails(emp);
	}
	// URL : http://host:port/employee/empId , method=DELETE
	// path variable
	@DeleteMapping("/{empId}")
	public String deleteEmpDetails(@PathVariable Long empId)
	{
		System.out.println("in del emp details "+empId);
		return empService.deleteEmpDetails(empId);
	}

}
