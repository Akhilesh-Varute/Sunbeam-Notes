package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.EmployeeDao;
import com.app.entities.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	// dependency : dao layer i/f
	@Autowired // =byType with field level D.I
	private EmployeeDao empDao;

	@Override
	public List<Employee> getAllEmps() {
		// TODO Auto-generated method stub
		return empDao.findAll();
	}

	@Override
	public Employee addEmpDetails(Employee emp) {
		// TODO Auto-generated method stub
		return empDao.save(emp);
	}// tx.commit
	/*
	 * Spring supplied Tx mgr will begin the tx?--when controller invokes
	 * 
	 * @Transactional method. It will end the tx --when service layer method
	 * returns. In case of no run time errs (un chked) exc --> tx.commit -->
	 * session.flush() -- DMLs : insert --> session.close() --> L1 cache is
	 * destroyed n db cn rets to the pool (currently DBCP vendor : Hikari) In case
	 * of run time err --> tx.rollback() --> session.close()
	 */

	@Override
	public Employee getEmpDetails(Long empId) {
		// TODO Auto-generated method stub
		return empDao.findById(empId).orElseThrow(() -> new ResourceNotFoundException("Invalid emp id !!!!!"));
	}

	@Override
	public Employee updateEmpDetails(Employee emp) {
		if (empDao.existsById(emp.getId())) {
			// emp : DETACHED
			return empDao.save(emp);
		}
		throw new ResourceNotFoundException("Invalid emp id , Details can't be updated!!!!");
	}//DML : update

	@Override
	public String deleteEmpDetails(Long empId) {
		if(empDao.existsById(empId))
		{
			empDao.deleteById(empId);
			return "Emp details deleted.....";
		}
		return "Emp details can't be deleted";
	}
	
	

}
