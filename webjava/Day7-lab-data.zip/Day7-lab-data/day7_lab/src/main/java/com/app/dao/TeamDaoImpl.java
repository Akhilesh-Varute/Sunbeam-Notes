package com.app.dao;

import com.app.pojos.Team;
import org.hibernate.*;
import static com.app.utils.HibernateUtils.getFactory;

import java.io.Serializable;

public class TeamDaoImpl implements TeamDao {

	@Override
	public String addNewTeam(Team newTeam) {
		String mesg="Adding team failed";
		// 1. Get session from SF
		Session session=getFactory().getCurrentSession();
		//2. Begin a tx
		Transaction tx=session.beginTransaction();
		//3 . try -save team details , commit ,
		//catch: runtime exc : rollback tx , throw e
		try {
			Serializable teamId = session.save(newTeam);
			tx.commit();
			mesg="Added new team details with ID="+teamId;
		} catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	
}
