package com.app.dao;

import com.app.pojos.Team;

public interface TeamDao {
//add a method to add new team
	String addNewTeam(Team newTeam);
}
